//
//  ViewController.swift
//  ATMVCB
//
//  Created by Thanh Dat on 19/08/2022.
//

import UIKit

var persons: [Person] = []
var banks: [Bank] = []
var atms: [ATM] = []
var cardDict: [String: Card] = [:]
var transactions: [String: [Transaction]] = [:]


class ViewController: UIViewController {
    
    
    @IBOutlet weak var txtLoginCardNumber: UITextField!
    
    @IBOutlet weak var txtLoginPIN: UITextField!
    
    @IBOutlet weak var btnLogin: UIButton!
    
    @IBOutlet weak var lblViewName: UILabel!
    
    @IBOutlet weak var lblViewMoney: UILabel!
    
    @IBOutlet weak var txtCardNumberReceive: UITextField!
    
    @IBOutlet weak var txtAmountOfMoney: UITextField!
    
    @IBOutlet weak var txtPinOfUser: UITextField!
    
    @IBOutlet weak var btnSendMoney: UIButton!
    
    @IBOutlet weak var btnWithdraw: UIButton!
    
    @IBOutlet weak var btnChangePIN: UIButton!
    
    @IBOutlet weak var txtNewPin: UITextField!
    
    @IBOutlet weak var lblThongBao: UILabel!
    
    var currentATM = ATM()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initData()
    }
    
    
    
    
    
    class User {
        var cardNumber: String?
        var pin: String?
        var amountMoney: Int = 0
        var name: String?
        var receiveCardNumber: String?
    }
    
    
    var members: [User] = []
    
    
    var count = 0;
    
    @IBAction func btnTapLogin(_ sender: UIButton) {
        let currentCard = currentATM.login(cardID: txtLoginCardNumber.text!, pin: Int(txtLoginPIN.text!)!)
        if currentCard != nil {
            lblViewName.text = "Chủ thẻ: \(currentCard!.getPersonInfo()!.fullName!)"
            lblViewName.backgroundColor = .green
            lblViewMoney.text = "Số dư: \(currentCard!.amount!)"
            lblViewMoney.backgroundColor = .yellow
        }
    }

    
    @IBAction func btnTapSendMoney(_ sender: UIButton) {
        let amount: Int = Int(txtAmountOfMoney.text!)!
        if members.count != 0 {
            for member in members {
                if txtLoginCardNumber.text == member.cardNumber && txtLoginPIN.text == member.pin {
                    if txtCardNumberReceive.text == "" || txtAmountOfMoney.text == "" || txtPinOfUser.text == "" {
                        lblThongBao.text = "Không thể thực hiện"
                    }
                    if amount <= member.amountMoney && txtCardNumberReceive.text == member.receiveCardNumber && txtPinOfUser.text == member.pin {
                        if let txtSendMoney: Int = Int(txtAmountOfMoney.text!) {
                            member.amountMoney = member.amountMoney - txtSendMoney
                            lblViewMoney.text = "\(member.amountMoney)"
                        }
                        lblThongBao.text = "Chuyển thành công"
                        lblThongBao.backgroundColor = .green
                    } else {
                        lblThongBao.text = "Không thể thực hiện"
                        lblThongBao.backgroundColor = .red
                    }
                } else {
                    lblThongBao.text = "Bạn chưa đăng nhập!"
                    lblThongBao.backgroundColor = .red
                }
            }
        }
        
    }
    
    
    @IBAction func btnTapWithdraw(_ sender: UIButton) {
        let amount: Int = Int(txtAmountOfMoney.text!)!
        if members.count != 0 {
            for member in members {
                if txtLoginCardNumber.text == member.cardNumber && txtLoginPIN.text == member.pin {
                    if txtCardNumberReceive.text == "" || txtAmountOfMoney.text == "" || txtPinOfUser.text == "" {
                        lblThongBao.text = "Không thể thực hiện"
                    }
                    if amount <= member.amountMoney && txtPinOfUser.text == member.pin {
                        if let txtSendMoney: Int = Int(txtAmountOfMoney.text!) {
                            member.amountMoney = member.amountMoney - txtSendMoney
                            lblViewMoney.text = "\(member.amountMoney)"
                        }
                        lblThongBao.text = "Rút thành công"
                        lblThongBao.backgroundColor = .green
                    } else {
                        lblThongBao.text = "Không thể thực hiện"
                        lblThongBao.backgroundColor = .red
                    }
                } else {
                    lblThongBao.text = "Bạn chưa đăng nhập!"
                    lblThongBao.backgroundColor = .red
                }
            }
        }
        
    }
    
    
    @IBAction func btnTapChangePin(_ sender: UIButton) {
        for member in members {
            if member.pin == txtLoginPIN.text! {
                member.pin = txtNewPin.text!
                lblThongBao.text = "Đổi mã PIN thành công"
            }
        }
        
    }
    
    func initData() {
        let firstPerson = Person()
        firstPerson.id = "1"
        firstPerson.fullName = "Nguyen Kha Chuong"
        persons.append(firstPerson)
        
        let chuongCard = Card()
        chuongCard.id = "190123456"
        chuongCard.personID = "1"
        chuongCard.bankID = "1"
        chuongCard.amount = 5000000
        chuongCard.expiredDate = "12/2022"
        chuongCard.pin = 1234
        
        cardDict["190123456"] = chuongCard
        
        currentATM.id = "1"
        currentATM.bankID = "1"
        currentATM.address = "15 Dich Vong Hau, Ha Noi"
        currentATM.status = "Dang hoat dong"
    }
    
}



class Person {
    var id: String?
    var fullName: String?
}

class Bank {
    var id: String?
    var name: String?
}

class Card {
    var id: String?
    var bankID: String?
    var personID: String?
    var expiredDate: String?
    var amount: Int?
    var pin: Int?
    var status: String?
    
    func changePIN(newPIN: String) -> Bool {
        return true
    }
    
    func getPersonInfo() -> Person? {
        for person in persons {
            if person.id == personID {
                return person
            }
        }
        return nil
    }
}

class ATM {
    var id: String?
    var bankID: String?
    var address: String?
    var status: String?
    
    func login(cardID: String, pin: Int) -> Card? {
        for (key, value) in cardDict {
            if key == cardID && value.pin == pin {
                return value
            }
        }
        return nil
    }
}

class Transaction {
    var id: String?
    var atmID: String?
    var cardID: String?
    var time: String?
    var action: String?
    var amount: Int?
    var receiverCardID: String?
    var status: String?
}

